# showapi_sdk_php
showapi_sdk_php  
功能:  
1.php模拟HTTP请求的实现  
2.针对万维易源 https://www.showapi.com 官网的接口,封装成PHP-SDK包,便于接口调用  
详见stand.php、base64.php、file.php三个文件的操作代码。  
